<?php $__env->startSection('judul','.::Register::.'); ?>

<?php $__env->startSection('isi_konten'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jameswijaya/Desktop/webdev09-laravel/resources/views/register.blade.php ENDPATH**/ ?>