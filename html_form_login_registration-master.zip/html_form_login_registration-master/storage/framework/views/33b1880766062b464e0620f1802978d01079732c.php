<?php $__env->startSection('judul','.::Login::.'); ?>

<?php $__env->startSection('isi_konten'); ?>
<div class="row">
    <div class='col-md-4 hidden-xs'>
    
    </div>
    <div class='col-md-4 col-xs-12'>
        <h3>Masuk</h3>
        <form action='/authenticate' method='POST'>
            <label for="Username">Username</label>
            <input class='form-control' type="text" name="nama_user" id="nama_user">
            <label for="Username">Password</label>
            <input class='form-control' type="password" name="kata_sandi" id="kata_sandi">
            <br>
            <button type='submit' class='btn btn-primary'>
                <i class='fa fa-sign-in'></i> Masuk
            </button>
            <button type='reset' class='btn btn-secondary'>
                <i class='fa fa-trash'></i> Batal
            </button>
            <a href='register.html'>Belum punya akun?</a>
        </form>
    </div>
    <div class='col-md-4 hidden-xs'>
    
    </div>
</div>
<div class='row'>
    &nbsp;
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jameswijaya/Desktop/webdev09-laravel/resources/views/login.blade.php ENDPATH**/ ?>