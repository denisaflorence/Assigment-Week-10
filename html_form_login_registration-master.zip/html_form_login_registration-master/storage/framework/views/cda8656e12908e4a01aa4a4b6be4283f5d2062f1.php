<form method='POST' action='/tangkap'>
    <?php echo e(csrf_field()); ?>

    Username: <input type="text" name="nama_user" id="">
    <br>
    Email: <input type="text" name="alamat_surat" id="">
    <br>
    <input type="submit" value="Kirim Gan!">
</form><?php /**PATH /Users/jameswijaya/Desktop/webdev09-laravel/resources/views/form.blade.php ENDPATH**/ ?>